public class TooManyMinesException extends Exception
{
}