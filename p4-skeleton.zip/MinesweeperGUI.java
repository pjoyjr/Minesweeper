import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MinesweeperGUI
{
   // TODO:  put your GUI code here

    public static void main(String[] args) 
    {
        // TODO:  this is the main method which should be used for the final
        // submission
    }
}