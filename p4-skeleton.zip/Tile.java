/**
 * Tile.java
 * 
 * Represents a single tile on the minesweeper board.
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Tile
{
    public static final int TILE_SIZE = 24;     // tile size for the GUI
    public static final int MINE = -1;          // mine identifier
    private int iCoord, jCoord;                 // position of the tile
    private int mineInformation;                // information about the tile
    private boolean flagged;                    // user placed a flag?
    private boolean visited;                    // tile selected by user

    public Tile(final int i, final int j)
    {
        iCoord = i;
        jCoord = j;
        mineInformation = 0;
        visited = false;
    }

    // sets the tile information
    public void setTileInformation(final int mineInformation)
    {
        this.mineInformation = mineInformation;
    }

    // sets a tile to be visited based on the boolean state
    public void setVisited(final boolean visited)
    {
        // TODO:  set this tile to be visited.  This method should be called
        // when this tile is selected by the GUI.
    }

    // sets a tile to be flagged based on the boolean state
    public void setFlagged(final boolean flagged)
    {
        // TODO:  set this tile to be flagged.  This method should be called
        // when this tile is selected by the GUI.
    }

    public int getTileInformation()
    {
        return mineInformation;
    }

    public boolean getVisited()
    {
        return visited;
    }

    public boolean getFlagged()
    {
        return flagged;
    }

    public String toString()
    {
        if (!flagged)
        {
            switch (mineInformation)
            {
                case MINE:
                    return "M";
                case 0:
                    return " ";
                default:
                    return "" + mineInformation;
            }
        }
        return "F";
    }
}